import json,sys,collections,pathlib
cap=pathlib.Path(sys.argv[1]); obs=pathlib.Path(r'C:/Users/mwam0/.codex/worktrees/i65-residual/TestResults/issue61-65/native-attribution-cold-01/observations')
driver=[json.loads(x) for x in (obs/'driver.jsonl').read_text(encoding='utf-8-sig').splitlines()]
a=next(x['ticks'] for x in driver if x['kind']=='scroll-phase-start'); b=next(x['ticks'] for x in driver if x['kind']=='scroll-phase-end')
stacks=collections.defaultdict(list); pairs=[]; names=collections.Counter(); examples={}; selected=[]
with (cap/'product-events.jsonl').open(encoding='utf-8-sig') as f, (cap/'scroll-events.jsonl').open('w') as out:
 for line in f:
  e=json.loads(line); t=e['TimeStampQPC']
  if not a<=t<=b:continue
  if e['ThreadID']!=30760:continue
  out.write(line); names[e['EventName']]+=1
  n=e['EventName']; examples.setdefault(n,e)
  if n.endswith('/Start'):stacks[n[:-6]].append(e)
  elif n.endswith('/Stop') and stacks[n[:-5]]:
   s=stacks[n[:-5]].pop(); dur=(t-s['TimeStampQPC'])/10000
   if dur>=2:pairs.append(dict(name=n[:-5],start=s['TimeStampQPC'],end=t,ms=dur,startPayload=s['payload'],endPayload=e['payload']))
report=dict(start=a,end=b,names=names,unpaired={n:len(v) for n,v in stacks.items() if v},longest=sorted(pairs,key=lambda x:-x['ms'])[:100],examples=examples)
(cap/'scroll-analysis.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:report[k] for k in ['start','end','unpaired']},indent=2));print(json.dumps(report['longest'][:18],indent=2));print('examples',json.dumps({k:v for k,v in examples.items() if any(n in k for n in ['MeasureElement/Start','ApplyTemplate/Start','ElementCreated','ArrangeElement/Start','Layout/Start'])},indent=2))
