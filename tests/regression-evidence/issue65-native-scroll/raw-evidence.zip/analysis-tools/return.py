import json,sys,pathlib,collections
cap=pathlib.Path(sys.argv[1]); rep=json.loads((cap/'scroll-analysis.json').read_text()); obs=pathlib.Path(r'C:/Users/mwam0/.codex/worktrees/i65-residual/TestResults/issue61-65/native-attribution-cold-01/observations'); drv=[json.loads(x) for x in (obs/'driver.jsonl').read_text().splitlines()];cmd=next(x['detail'] for x in drv if x['kind']=='scroll-input' and x['detail']['index']==3);frame=next(x for x in rep['longest'] if x['name']=='Frame' and cmd['begin']<=x['start']<cmd['begin']+2000000); a,b=frame['start'],frame['end']; stack=[]; totals=collections.defaultdict(lambda:[0,0,0]);names=collections.Counter(); classes={}; lifetime=collections.Counter(); measured=set(); details=[]
for line in (cap/'scroll-events.jsonl').open():
 e=json.loads(line);t=e['TimeStampQPC'];n=e['EventName'];p=e['payload']
 if n=='ApplyTemplate/Start':classes[p.get('ElementId')]=p.get('ClassName')
 if not a<=t<=b:continue
 names[n]+=1
 if 'ElementId' in p:measured.add(p['ElementId'])
 if n.endswith('/Start'):stack.append([n[:-6],t,0,p])
 elif n.endswith('/Stop') and stack and stack[-1][0]==n[:-5]:
  op,st,child,sp=stack.pop();dt=(t-st)/10000
  if stack:stack[-1][2]+=dt
  totals[op][0]+=1;totals[op][1]+=dt;totals[op][2]+=dt-child
  if dt>2:details.append(dict(op=op,ms=dt,exclusive=dt-child,start=st,end=t,payload=sp))
print('frame',frame,'cmd',cmd);print('totals count/inclusive/exclusive',sorted(totals.items(),key=lambda x:-x[1][2])[:20]);print('details',json.dumps(sorted(details,key=lambda x:-x['exclusive'])[:14],indent=2));print('creation',[(n,v) for n,v in names.items() if any(s in n for s in ['Create','Destroy','Generate','Clear','Template'])]);print('classes',collections.Counter(classes.get(k) for k in measured));(cap/'return3.json').write_text(json.dumps(dict(frame=frame,cmd=cmd,totals=totals,details=details,names=names),indent=2))
