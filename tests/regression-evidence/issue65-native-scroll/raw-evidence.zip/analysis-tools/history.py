import json,pathlib,hashlib
c=pathlib.Path(__file__).parent/'capture-20260922-150303';out=pathlib.Path(__file__).parent/'scoped-evidence/native';r=json.loads((c/'return81-reuse.json').read_text());ids={int(k) for k in r['elements']};stop=r['frame']['end']
with (out/'selected-element-history.jsonl').open('w') as dst:
 for line in (c/'product-events.jsonl').open():
  e=json.loads(line)
  if e['TimeStampQPC']>stop:break
  if e['payload'].get('ElementId') in ids and e['EventName'] in ['ApplyTemplate/Start','ElementCreated','ElementDestroyed']:dst.write(line)
with (c/'native.etl').open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
(out/'private-trace-provenance.json').write_text(json.dumps(dict(path=str(c/'native.etl'),bytes=(c/'native.etl').stat().st_size,sha256=h,publication='private system-wide trace; not included',extractedProcess=32668,extractedUiThread=30760),indent=2))
print('element history bytes',(out/'selected-element-history.jsonl').stat().st_size,'ETL hash',h)
