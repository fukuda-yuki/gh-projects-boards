import json,pathlib,collections
c=pathlib.Path(__file__).parent/'capture-20260922-150303'
r=json.loads((c/'return81.json').read_text());a,b=r['frame']['start'],r['frame']['end']
events=[json.loads(l) for l in (c/'ui-scheduling.jsonl').read_text().splitlines()];state='unknown';last=events[0]['ticks'];totals=collections.Counter();intervals=[]
for e in events:
 t=e['ticks'];start=max(last,a);end=min(t,b)
 if end>start:totals[state]+=(end-start)/10000;intervals.append(dict(state=state,start=start,end=end,ms=(end-start)/10000))
 if e['kind']=='ready':
  if state!='running':state='ready'
 elif e['newId']==30760:state='running'
 elif e['oldId']==30760:state='ready' if e['state'] in (1,3) else 'waiting'
 last=t
 if t>=b:break
print(dict(totals));(c/'return81-scheduling.json').write_text(json.dumps(dict(totals=totals,intervals=intervals),indent=2))
