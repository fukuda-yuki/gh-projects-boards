import json,sys,pathlib
root=pathlib.Path(sys.argv[1]);load=lambda n:json.loads((root/n).read_text(encoding='utf-8-sig'));plan=load('plan.json');freq=plan['frequency'];tr=[json.loads(l) for l in (root/'app-trace.jsonl').read_text().splitlines()];driver=[json.loads(l) for l in (root/'driver.jsonl').read_text().splitlines()];cmds=load('native-command-classification.json')['commands'];phase=next(e['ticks'] for e in driver if e['kind']=='scroll-phase-start');end=next(e['ticks'] for e in driver if e['kind']=='scroll-phase-end');last=load('native-command-classification.json')['lastCommit'];out=[]
for e in tr:
 if e['kind']!='rendering-callback' or not phase<=e['ticks']<=end:continue
 gap=e['data'].get('previousGapTicks')
 if not gap or gap*1000/freq<100:continue
 a=e['ticks']-gap;b=e['ticks'];sp=[x['data'] for x in tr if x['kind']=='ui-span' and x['data']['start']<b and x['data']['end']>a];uiThread=e['thread'];intervals=sorted((max(a,s['start']),min(b,s['end'])) for s in sp if s['thread']==uiThread and s['endThread']==uiThread);union=[]
 for x,y in intervals:
  if union and x<=union[-1][1]:union[-1][1]=max(union[-1][1],y)
  else:union.append([x,y])
 measured=sum(y-x for x,y in union)*1000/freq;commands=[c for c in cmds if c.get('begin',b)<b and c.get('end',a)>a];out.append(dict(start=a,end=b,ms=gap*1000/freq,postSave=a>=last,managedUiSpanUnionMs=measured,unaccountedWallMs=gap*1000/freq-measured,commands=commands,spans=sp,disposition='This app-span ledger does not fully attribute the interval. Native attribution is separate. Union is wall time, not CPU; do not add inclusive spans or infer GC from overlap.'))
(root/'native-scroll-intervals.json').write_text(json.dumps(out,indent=2));print(root.parent.name,len(out))

