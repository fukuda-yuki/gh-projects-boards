import json,pathlib,shutil,hashlib,zipfile,collections,datetime
repo=pathlib.Path.cwd(); task=repo/'TestResults/issue65-native-preflight'; cap=task/'capture-20260922-150303'; dest=repo/'tests/regression-evidence/issue65-native-scroll'; raw=task/'scoped-evidence';raw.mkdir(exist_ok=True);runs=pathlib.Path(r'C:/Users/mwam0/.codex/worktrees/i65-residual/TestResults/issue61-65');names=['native-attribution-cold-01','native-baseline-short-01','native-candidate-short-01']+[f'native-final-{c}-{i:02}' for i in range(1,4) for c in ['cold','warm']]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));summaries=[]
def cp(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for name in names:
 root=runs/name;obs=root/'observations';target=raw/'runs'/name;plan=read(obs/'plan.json');m=read(obs/'measurements.json');cl=read(obs/'native-command-classification.json');intervals=read(obs/'native-scroll-intervals.json')
 summaries.append(dict(run=name,source=plan['source'],condition=plan['condition'],executableSha256=plan['executableSha256'],appSha256=plan['appSha256'],coreSha256=plan['coreSha256'],driverSha256=plan['driverSha256'],traceComplete=m['traceComplete'],typed=m['typed'],renderingGaps=m['renderingGaps'],captureGaps=m['captureGaps'],commandCounts=cl['counts'],postSaveCounts=cl['postSaveCounts'],scrollIntervals=len(intervals),state='PASS',scroll='FAIL',profiled=name=='native-attribution-cold-01'))
 for f in ['environment.json','diagnostic.trx','test.log','seed.log']:
  if (root/f).exists():cp(root/f,target/f)
 for f in ['plan.json','driver.jsonl','app-trace.jsonl','measurements.json','scroll-captures.json','native-command-classification.json','native-scroll-intervals.json','durable-readback.json','lifetime.json']:
  cp(obs/f,target/'observations'/f)
 for command in cl['commands']:
  if command['classification']=='corroborated-app-delay' or (name in ['native-baseline-short-01','native-candidate-short-01'] and command['index']==19):
   for key in ['before','lastUnchanged','firstChanged']:
    if command.get(key):cp(obs/command[key],target/'observations'/command[key])
(dest/'runs.json').write_text(json.dumps(summaries,indent=2))
frame=read(cap/'return81.json')['frame'];a,b=frame['start'],frame['end'];native=raw/'native';native.mkdir(exist_ok=True)
with (native/'selected-frame-events.jsonl').open('w') as out:
 for line in (cap/'scroll-events.jsonl').open():
  e=json.loads(line)
  if a<=e['TimeStampQPC']<=b:out.write(line)
  if e['TimeStampQPC']>b:break
with (native/'selected-frame-samples.jsonl').open('w') as out:
 for line in (cap/'ui-samples-symbols.jsonl').open():
  e=json.loads(line)
  if a<=e['TimeStampQPC']<=b:out.write(line)
  if e['TimeStampQPC']>b:break
for f in ['trace-metadata.json','return81.json','return81-reuse.json','return81-scheduling.json','clock-alignment.json']:
 cp(cap/f,native/f)
modules=[{k:(pathlib.PureWindowsPath(v).name if k in ['FilePath','PdbName'] else v) for k,v in m.items()} for m in read(cap/'modules.json') if 'final-app' in m['FilePath']]
summary=dict(processId=32668,osUiThreadId=30760,managedThreadId=2,frame=frame,scheduling=read(cap/'return81-scheduling.json')['totals'],reuse={k:v for k,v in read(cap/'return81-reuse.json').items() if k!='elements'},clock=read(cap/'clock-alignment.json'),trace=read(cap/'trace-metadata.json'),modules=modules,symbols=dict(xamlAddresses=10003,xamlMatched=9969,xamlUnmatched=34,controlsAddresses=305,controlsMatched=305,outOfRangeNames='Preserved with ?? prefix; not trusted attribution'),boundary='Raw XAML analysis with installed TraceEvent, no WPA plugin claim. Full system ETL/ETLX and PDBs remain private. Candidate WPR start cancelled before recording.')
(dest/'native-attribution.json').write_text(json.dumps(summary,indent=2))
# Retain original unedited pixels for the selected native interval and inspected UI views.
pix=dest/'pixels';pix.mkdir(exist_ok=True);provenance=[]
for f in ['scroll-0233.png','scroll-0236.png','scroll-0237.png']:
 src=runs/'native-attribution-cold-01/observations'/f;cp(src,pix/('native-'+f));provenance.append(dict(source=str(src),file='pixels/native-'+f,sha256=hashlib.sha256(src.read_bytes()).hexdigest()))
for label,p in [('light',r'C:/Users/mwam0/AppData/Local/Temp/ghpb-theme-ca15ceec80e64e978682060dd45033de/workspace-light.png'),('dark',r'C:/Users/mwam0/AppData/Local/Temp/ghpb-theme-03c007d361c74d5aab746712d4523c4c/workspace-dark.png'),('focused-return',r'C:/Users/mwam0/AppData/Local/Temp/ghpb-focused-scroll-221ec0e289424b98a057208df70d40f9/04-return-top-left.png')]:
 src=pathlib.Path(p);cp(src,pix/(label+'.png'));provenance.append(dict(source=str(src),file='pixels/'+label+'.png',sha256=hashlib.sha256(src.read_bytes()).hexdigest()))
(dest/'pixels.json').write_text(json.dumps(provenance,indent=2))
for run in ['run-20260922-151617-567-38d63a42','run-20260922-151920-517-abf4ea18','run-20260922-153114-950-a9bbaf44']:
 for p in (repo/'TestResults/ui-integration'/run).iterdir():
  if p.is_file():cp(p,raw/'ui-integration'/run/p.name)
e2e=repo/'TestResults/e2e/20260922-153244-35d8d78f164f47758f4f4529827c44bf'
for p in e2e.iterdir():
 if p.is_file() and not p.name.endswith('assets.json'):cp(p,raw/'e2e'/p.name)
for p in task.glob('*.py'):cp(p,raw/'analysis-tools'/p.name)
for name in ['Program.events.txt','Program.symbols.txt','Program.cs','Parser.csproj']:cp(task/'parser'/name,raw/'analysis-tools'/name)
for name in ['capture.ps1','start.txt','stop.txt','stop-exit.txt','status-before.txt','status-after.txt','symbols-xaml-only.log']:
 cp(cap/name,raw/'native'/name)
cp(task/'long-title-build.log',raw/'build/long-title-build.log')
with zipfile.ZipFile(dest/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(raw.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(raw).as_posix())
manifest=[dict(path=p.relative_to(dest).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(dest.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json'];(dest/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2));print('archive', (dest/'raw-evidence.zip').stat().st_size,'raw files',sum(p.is_file() for p in raw.rglob('*')))
