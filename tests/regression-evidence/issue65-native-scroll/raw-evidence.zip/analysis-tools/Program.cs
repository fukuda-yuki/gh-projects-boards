using Microsoft.Diagnostics.Tracing.Etlx;
using System.Text.Json;
using var trace=new TraceLog(args[0]);
using var output=new StreamWriter(args[1]);
foreach(var e in trace.Events){
 if(e.TimeStampQPC<5564100201197 || e.TimeStampQPC>5564718427189) continue;
 if(e.EventName=="Thread/CSwitch") {
   var oldId=(int)e.PayloadByName("OldThreadID"); var newId=(int)e.PayloadByName("NewThreadID");
   if(oldId!=30760 && newId!=30760) continue;
   output.WriteLine(JsonSerializer.Serialize(new{ticks=e.TimeStampQPC,kind="switch",oldId,newId,state=e.PayloadByName("OldThreadState"),cpu=e.ProcessorNumber}));
 } else if(e.EventName=="Dispatcher/ReadyThread" && (int)e.PayloadByName("AwakenedThreadID")==30760)
   output.WriteLine(JsonSerializer.Serialize(new{ticks=e.TimeStampQPC,kind="ready"}));
}
