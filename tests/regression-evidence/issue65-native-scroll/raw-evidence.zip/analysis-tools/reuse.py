import json,pathlib,collections
c=pathlib.Path(__file__).parent/'capture-20260922-150303';r=json.loads((c/'return81.json').read_text());a,b=r['frame']['start'],r['frame']['end'];ids=set();
for l in (c/'scroll-events.jsonl').open():
 e=json.loads(l)
 if a<=e['TimeStampQPC']<=b and e['EventName']=='ApplyTemplate/Start' and e['payload'].get('ClassName')=='Microsoft.UI.Xaml.Controls.TextBox':ids.add(e['payload']['ElementId'])
observations={i:dict(firstApplied=None,lastAppliedBefore=None,created=None,destroyedBefore=None) for i in ids}
for l in (c/'product-events.jsonl').open():
 e=json.loads(l);t=e['TimeStampQPC']
 if t>=a:break
 i=e['payload'].get('ElementId')
 if i not in observations:continue
 o=observations[i]
 if e['EventName']=='ApplyTemplate/Start':
  if o['firstApplied'] is None:o['firstApplied']=t
  o['lastAppliedBefore']=t
 elif e['EventName']=='ElementCreated':o['created']=t
 elif e['EventName']=='ElementDestroyed':o['destroyedBefore']=t
result=dict(frame=r['frame'],textBoxes=len(ids),seenBefore=sum(o['lastAppliedBefore'] is not None for o in observations.values()),destroyedBetween=sum(o['destroyedBefore'] is not None and o['firstApplied'] is not None and o['destroyedBefore']>=o['firstApplied'] for o in observations.values()),elements=observations)
(c/'return81-reuse.json').write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items() if k!='elements'})
