$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$started = $false
try {
    & "$env:SystemRoot\System32\wpr.exe" -status *> (Join-Path $root 'status-before.txt')
    & "$env:SystemRoot\System32\wpr.exe" -start CPU -start XAMLActivity -filemode *> (Join-Path $root 'start.txt')
    if ($LASTEXITCODE -ne 0) { throw "WPR start failed: $LASTEXITCODE" }
    $started = $true
    [IO.File]::WriteAllText((Join-Path $root 'ready.txt'), [DateTimeOffset]::UtcNow.ToString('O'))
    $deadline = [DateTimeOffset]::UtcNow.AddMinutes(6)
    while (-not (Test-Path -LiteralPath (Join-Path $root 'stop.request')) -and [DateTimeOffset]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 250 }
} catch { $_ | Out-String | Set-Content -LiteralPath (Join-Path $root 'error.txt') }
finally {
    if ($started) {
        & "$env:SystemRoot\System32\wpr.exe" -stop (Join-Path $root 'native.etl') *> (Join-Path $root 'stop.txt')
        $LASTEXITCODE | Set-Content -LiteralPath (Join-Path $root 'stop-exit.txt')
    }
    & "$env:SystemRoot\System32\wpr.exe" -status *> (Join-Path $root 'status-after.txt')
    [IO.File]::WriteAllText((Join-Path $root 'done.txt'), [DateTimeOffset]::UtcNow.ToString('O'))
}
