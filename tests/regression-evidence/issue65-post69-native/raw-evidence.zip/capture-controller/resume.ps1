$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$driver = 'C:\Users\mwam0\.codex\worktrees\i65-residual'
$app = 'C:\Users\mwam0\.copilot\repos\gh-projects-boards\TestResults\issue65-native-preflight\trial-app\GhProjectsBoards.App.exe'
$source = '94922ffd17489b464bf8f23376e702ad1ef8600f'
if ((Get-FileHash -LiteralPath ([IO.Path]::ChangeExtension($app, '.dll'))).Hash -ne 'DEEB7F5387AD67C84E6476890738597740269E6CD5384B03201A3FB012AC7470') { throw 'Candidate binary changed.' }
if (Test-Path -LiteralPath (Join-Path $root 'launch-attempt.json')) { throw 'This launcher is single-use. No automatic retry is permitted.' }
if (Get-Process -Name GhProjectsBoards.App,GhProjectsBoards.UiIntegration.Tests -ErrorAction SilentlyContinue) { throw 'Another product/UI run exists. Stop this acquisition without terminating it.' }
@{requestedUtc=[DateTimeOffset]::UtcNow.ToString('O'); captureOnly=$true; instance='GHPB-I65-Post69-Candidate-01'; source=$source} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root 'launch-attempt.json')
$helper = $null
try {
    # Only this bounded WPR controller is elevated. The following replay remains in this ordinary process.
    $helper = Start-Process -FilePath 'C:\Program Files\PowerShell\7\pwsh.exe' -Verb RunAs -WindowStyle Hidden -ArgumentList @('-NoProfile','-File',('"' + (Join-Path $root 'capture.ps1') + '"')) -PassThru
    $deadline = [DateTimeOffset]::UtcNow.AddSeconds(60)
    while (-not (Test-Path -LiteralPath (Join-Path $root 'ready.txt'))) {
        if ($helper.HasExited -or [DateTimeOffset]::UtcNow -ge $deadline) { throw 'Capture did not become ready. See retained helper status; do not relaunch.' }
        Start-Sleep -Milliseconds 250
    }
    Push-Location -LiteralPath $driver
    try {
        & .\scripts\Test-SustainedInput.ps1 -Executable $app -SourceRevision $source -RunId post69-native-candidate-cold-01 -Condition cold -Mode standard -TraceDetail light *> (Join-Path $root 'cold-driver.log')
        & .\scripts\Test-SustainedInput.ps1 -Executable $app -SourceRevision $source -RunId post69-native-candidate-warm-01 -Condition warm -Mode standard -TraceDetail light *> (Join-Path $root 'warm-driver.log')
    } finally { Pop-Location }
} catch {
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $root 'launch-or-replay-error.txt')
    throw
} finally {
    [IO.File]::WriteAllText((Join-Path $root 'stop.request'), [DateTimeOffset]::UtcNow.ToString('O'))
}
Write-Output 'Replay ended; the bounded elevated helper is finalizing its own native.etl. Check done.txt and stop-exit.txt before analysis.'
