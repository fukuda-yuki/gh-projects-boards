$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$instance = 'GHPB-I65-Post69-Candidate-01'
$wpr = Join-Path $env:SystemRoot 'System32\wpr.exe'
$started = $false
$failed = $false
try {
    if (Test-Path -LiteralPath (Join-Path $root 'ready.txt')) { throw 'This capture already ran. Preserve it; do not retry.' }
    $before = & $wpr -status 2>&1
    $before | Set-Content -LiteralPath (Join-Path $root 'status-default-before.txt')
    if (($before -join "`n") -notmatch 'WPR is not recording') { throw 'Another default WPR recording may exist. Nothing was stopped.' }
    $ownedBefore = & $wpr -status -instancename $instance 2>&1
    $ownedBefore | Set-Content -LiteralPath (Join-Path $root 'status-owned-before.txt')
    if (($ownedBefore -join "`n") -notmatch 'WPR is not recording') { throw 'The named instance is not confirmed idle. Nothing was stopped.' }
    & $wpr -start CPU -start XAMLActivity -filemode -instancename $instance *> (Join-Path $root 'start.txt')
    if ($LASTEXITCODE -ne 0) { throw "WPR start failed: $LASTEXITCODE. No retry or global cancellation." }
    $started = $true
    [IO.File]::WriteAllText((Join-Path $root 'ready.txt'), [DateTimeOffset]::UtcNow.ToString('O'))
    $deadline = [DateTimeOffset]::UtcNow.AddMinutes(6)
    while (-not (Test-Path -LiteralPath (Join-Path $root 'stop.request')) -and [DateTimeOffset]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 250 }
} catch {
    $failed = $true
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $root 'error.txt')
} finally {
    if ($started) {
        & $wpr -stop (Join-Path $root 'native.etl') -instancename $instance *> (Join-Path $root 'stop.txt')
        $stopExit = $LASTEXITCODE
        $stopExit | Set-Content -LiteralPath (Join-Path $root 'stop-exit.txt')
        if ($stopExit -ne 0) {
            $failed = $true
            # Failed finalization must not leave this task's recording active.
            & $wpr -cancel -instancename $instance *> (Join-Path $root 'owned-cancel-after-stop-failure.txt')
            $LASTEXITCODE | Set-Content -LiteralPath (Join-Path $root 'owned-cancel-exit.txt')
        }
    }
    & $wpr -status -instancename $instance *> (Join-Path $root 'status-owned-after.txt')
    [IO.File]::WriteAllText((Join-Path $root 'done.txt'), [DateTimeOffset]::UtcNow.ToString('O'))
}
if ($failed) { exit 1 }
