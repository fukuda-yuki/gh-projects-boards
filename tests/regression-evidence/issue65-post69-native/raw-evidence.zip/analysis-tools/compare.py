import collections,datetime,json,pathlib
root=pathlib.Path(__file__).parent.parent
baseline=root.parent/'issue65-native-preflight'/'capture-20260922-150303'
runs=pathlib.Path(r'C:/Users/mwam0/.codex/worktrees/i65-residual/TestResults/issue61-65')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
lines=lambda p:[json.loads(l) for l in p.read_text(encoding='utf-8-sig').splitlines()]
result={}
for label,framepath,samplepath,schedpath,obs,meta in [
 ('baseline',root/'analysis/baseline-frames.json',baseline/'ui-samples-xaml.jsonl',baseline/'ui-scheduling.jsonl',runs/'native-attribution-cold-01/observations',baseline/'trace-metadata.json'),
 *[(c,root/f'candidate-01/{c}/frames.json',root/f'candidate-01/{c}/details/samples.jsonl',root/f'candidate-01/{c}/details/scheduling.jsonl',runs/f'post69-native-candidate-{c}-01/observations',root/f'candidate-01/{c}/trace-metadata.json') for c in ['cold','warm']]]:
    frames=read(framepath); samples=lines(samplepath); scheduling=lines(schedpath)
    sync=next(e['detail'] for e in lines(obs/'driver.jsonl') if e['kind']=='clock-sync')
    first=samples[0]; start=datetime.datetime.fromisoformat(read(meta)['SessionStartTime']); utc=datetime.datetime.fromisoformat(sync['utc'])
    lo=start+datetime.timedelta(milliseconds=first['TimeStampRelativeMSec'],seconds=(sync['before']-first['TimeStampQPC'])/10000000)
    hi=start+datetime.timedelta(milliseconds=first['TimeStampRelativeMSec'],seconds=(sync['after']-first['TimeStampQPC'])/10000000)
    comparisons=[]
    for cmd in frames['commands']:
        if cmd['command']['index'] not in (12,81,91):continue
        frame=cmd['frame'];a,b=frame['start'],frame['end'];selected=[s for s in samples if a<=s['TimeStampQPC']<=b]
        inclusive=collections.Counter();leaf=collections.Counter();paths=collections.Counter()
        for s in selected:
            names=[f.rsplit('@',1)[0] for f in s['frames']]
            inclusive.update(set(names));leaf.update(names[:1]);paths.update('EnterImpl' if any('EnterImpl' in n for n in names) else 'Measure' if any('Measure' in n for n in names) else 'Other' for _ in [0])
        state='unknown';last=scheduling[0]['ticks'];totals=collections.Counter()
        for e in scheduling:
            t=e['ticks'];x=max(a,last);y=min(b,t)
            if y>x:totals[state]+=(y-x)/10000
            if e['kind']=='ready':
                if state!='running':state='ready'
            elif e['newId']==frames['uiTid']:state='running'
            elif e['oldId']==frames['uiTid']:state='ready' if e['state'] in (1,3) else 'waiting'
            last=t
            if t>=b:break
        textboxes=[(k,v) for k,v in cmd['identities'].items() if v['cls']=='Microsoft.UI.Xaml.Controls.TextBox']
        created=[(k,v) for k,v in textboxes if v['createdInFrame']]
        comparisons.append(dict(index=cmd['command']['index'],frameMs=frame['ms'],schedulingMs=dict(totals),nativeCreated=cmd['nativeCreated'],textboxes=len(textboxes),newTextBoxes=len(created),previousTextBoxes=sum(v['firstSeen']<a for k,v in textboxes),rows=cmd['rows'],createdRows=sorted({r for k,v in created for r in v['rows'] if r is not None}),sampleCount=len(selected),paths=dict(paths),inclusiveNative=[(k,v) for k,v in inclusive.most_common() if k.startswith('microsoft.ui.xaml!')][:40],leaf=leaf.most_common(12),enterSamples=sum(any('EnterImpl' in f for f in s['frames']) for s in selected),themeReferenceSamples=sum(any('UpdateAllThemeReferences' in f for f in s['frames']) for s in selected)))
    result[label]=dict(clock=dict(sync=sync,lower=lo.isoformat(),upper=hi.isoformat(),utcMinusLowerMs=(utc-lo).total_seconds()*1000,utcMinusUpperMs=(utc-hi).total_seconds()*1000),uiTid=frames['uiTid'],commands=comparisons)
(root/'analysis/comparison.json').write_text(json.dumps(result,indent=2))
for k,v in result.items():
    print(k, json.dumps(v,indent=2))
