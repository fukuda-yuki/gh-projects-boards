using Microsoft.Diagnostics.Tracing.Etlx;
using Microsoft.Diagnostics.Symbols;
using System.Text.Json;
if(args.Length!=7) throw new ArgumentException("Details <etlx> <pid> <ui-tid> <start-qpc> <end-qpc> <new-output> <existing-symbol-cache>");
var pid=int.Parse(args[1]); var tid=int.Parse(args[2]); var start=long.Parse(args[3]); var end=long.Parse(args[4]); var output=args[5];
if(Directory.Exists(output)) throw new IOException("Preserve existing extracts."); Directory.CreateDirectory(output);
using var trace=new TraceLog(args[0]);
using var symbolLog=new StreamWriter(Path.Combine(output,"symbols.log")){AutoFlush=true};
using var reader=new SymbolReader(symbolLog,"srv*"+args[6]+"*https://msdl.microsoft.com/download/symbols");
reader.SecurityCheck=p=>true;
foreach(var m in trace.ModuleFiles.Where(m=>(m.FilePath.Contains("trial-app")||m.FilePath.Contains("final-app")) && Path.GetFileName(m.FilePath).Equals("microsoft.ui.xaml.dll",StringComparison.OrdinalIgnoreCase))) {
    symbolLog.WriteLine($"Product module: {m.FilePath}; PDB={m.PdbSignature}/{m.PdbAge}");
    try { trace.CodeAddresses.LookupSymbolsForModule(reader,m); } catch(Exception ex) { symbolLog.WriteLine(ex); }
}
using var samples=new StreamWriter(Path.Combine(output,"samples.jsonl"));
using var scheduling=new StreamWriter(Path.Combine(output,"scheduling.jsonl"));
foreach(var e in trace.Events) {
    if(e.TimeStampQPC<start||e.TimeStampQPC>end) continue;
    if(e.ProcessID==pid && e.ThreadID==tid && e.EventName.Contains("Sample")) {
        var frames=new List<string>();
        for(var s=trace.GetCallStackForEvent(e);s!=null;s=s.Caller) frames.Add(s.CodeAddress.ModuleName+"!"+s.CodeAddress.FullMethodName+"@"+s.CodeAddress.Address.ToString("x"));
        samples.WriteLine(JsonSerializer.Serialize(new{e.TimeStampQPC,e.TimeStampRelativeMSec,e.ThreadID,e.EventName,frames}));
    }
    if(e.EventName=="Thread/CSwitch") {
        var oldId=(int)e.PayloadByName("OldThreadID"); var newId=(int)e.PayloadByName("NewThreadID");
        if(oldId==tid||newId==tid) scheduling.WriteLine(JsonSerializer.Serialize(new{ticks=e.TimeStampQPC,kind="switch",oldId,newId,state=e.PayloadByName("OldThreadState"),cpu=e.ProcessorNumber}));
    } else if(e.EventName=="Dispatcher/ReadyThread" && (int)e.PayloadByName("AwakenedThreadID")==tid) {
        scheduling.WriteLine(JsonSerializer.Serialize(new{ticks=e.TimeStampQPC,kind="ready"}));
    }
}
Console.WriteLine($"PID={pid} TID={tid} QPC={start}..{end}; Lost={trace.EventsLost}");
