using Microsoft.Diagnostics.Tracing;
using Microsoft.Diagnostics.Tracing.Etlx;
using Microsoft.Diagnostics.Symbols;
using System.Text.Json;
if(args.Length!=3) throw new ArgumentException("Usage: Parser <private-etl> <synthetic-pid> <new-private-output-directory>");
var path=args[0]; var pid=int.Parse(args[1]); var output=args[2];
if(Directory.Exists(output)) throw new IOException("Preserve previous extracts; choose a new output directory."); Directory.CreateDirectory(output);
using var log=new StreamWriter(Path.Combine(output,"conversion.txt"),true){AutoFlush=true};
var etlx=Path.ChangeExtension(path,"etlx");
if(!File.Exists(etlx)) TraceLog.CreateFromEventTraceLogFile(path,etlx,new TraceLogOptions{ConversionLog=log});
using var trace=new TraceLog(etlx);
File.WriteAllText(Path.Combine(output,"trace-metadata.json"),JsonSerializer.Serialize(new{trace.EventCount,trace.EventsLost,trace.HasCallStacks,trace.SessionStartTime,trace.SessionEndTime,trace.FirstTimeInversion}));
using var writer=new StreamWriter(Path.Combine(output,"product-events.jsonl"));
var counts=new Dictionary<string,int>();
foreach(var e in trace.Events){
 if(e.ProcessID!=pid) continue;
 var key=e.ProviderName+"/"+e.EventName;
 counts[key]=counts.GetValueOrDefault(key)+1;
 var payload=new Dictionary<string,object>();
 foreach(var n in e.PayloadNames) {try{var v=e.PayloadByName(n); payload[n]=v is float f && !float.IsFinite(f) ? f.ToString() : v is double d && !double.IsFinite(d) ? d.ToString() : v;}catch{}}
 var frames=new List<string>();
 if(e.EventName.Contains("Sample")||e.ProviderName.Contains("XAML",StringComparison.OrdinalIgnoreCase))
 for(var s=trace.GetCallStackForEvent(e);s!=null;s=s.Caller) frames.Add(s.CodeAddress.ModuleName+"!"+s.CodeAddress.FullMethodName+"@"+s.CodeAddress.Address.ToString("x"));
 writer.WriteLine(JsonSerializer.Serialize(new{e.TimeStampQPC,e.TimeStampRelativeMSec,e.ThreadID,e.ProviderName,e.EventName,id=(int)e.ID,opcode=(int)e.Opcode,payload,frames}));
}
File.WriteAllText(Path.Combine(output,"event-counts.json"),JsonSerializer.Serialize(counts.OrderByDescending(k=>k.Value)));
File.WriteAllText(Path.Combine(output,"modules.json"),JsonSerializer.Serialize(trace.ModuleFiles.Where(m=>m.Name.Contains("xaml",StringComparison.OrdinalIgnoreCase)).Select(m=>new{m.FilePath,m.FileVersion,m.PdbName,m.PdbSignature,m.PdbAge,m.CodeAddressesInModule})));
Console.WriteLine($"Events={trace.EventCount} Lost={trace.EventsLost} Stacks={trace.HasCallStacks} ProductKinds={counts.Count}");

