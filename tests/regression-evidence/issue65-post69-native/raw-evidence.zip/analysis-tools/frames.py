import bisect, collections, json, pathlib, sys

events, observations, destination = map(pathlib.Path, sys.argv[1:4])
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
driver = [json.loads(l) for l in (observations/'driver.jsonl').read_text(encoding='utf-8-sig').splitlines()]
commands = [e['detail'] for e in driver if e['kind']=='scroll-input']
plan = read(observations/'plan.json'); frequency = plan['frequency']
indices = {12, 81, 91}
classification = observations/'native-command-classification.json'
if classification.exists():
    indices.update(c['index'] for c in read(classification)['commands'] if c['classification']=='corroborated-app-delay')
windows = [(c['begin']-500000, (commands[n+1]['begin'] if n+1<len(commands) else c['begin']+2200000)+500000) for n,c in enumerate(commands) if c['index'] in indices]
windows.sort(); starts = [w[0] for w in windows]
def selected(t):
    i = bisect.bisect_right(starts,t)-1
    return i>=0 and t<=windows[i][1]
def union_ms(intervals):
    result=0; a=b=None
    for x,y in sorted(intervals):
        if a is None: a,b=x,y
        elif x>b: result+=b-a; a,b=x,y
        else: b=max(b,y)
    if a is not None: result+=b-a
    return result*1000/frequency
classes={}; lifetimes={}; op_stacks=collections.defaultdict(list); frames=[]; spans=[]; retained=[]; malformed=collections.Counter(); tids=collections.Counter(); active_places=collections.defaultdict(list)
with events.open(encoding='utf-8-sig') as stream:
    for line in stream:
        e=json.loads(line); t=e['TimeStampQPC']; name=e['EventName']; tid=e['ThreadID']; p=e.get('payload',{}); element=p.get('ElementId')
        if element is not None:
            life=lifetimes.setdefault(element,dict(first=t,created=[],destroyed=[],classes=[],rows=[]))
            if name=='ElementCreated': life['created'].append(t)
            elif name=='ElementDestroyed': life['destroyed'].append(t)
            elif name=='ApplyTemplate/Start':
                cls=p.get('ClassName'); classes[element]=cls
                if not life['classes'] or life['classes'][-1][1]!=cls: life['classes'].append([t,cls])
            if active_places[tid]:
                row=active_places[tid][-1][1]
                if not life['rows'] or life['rows'][-1][1]!=row: life['rows'].append([t,row])
        if name=='Frame/Start': tids[tid]+=1
        if name=='PlaceElement/Start': active_places[tid].append((t,p.get('ItemIndex')))
        if selected(t): retained.append(dict(t=t,tid=tid,name=name,p=p,row=active_places[tid][-1][1] if active_places[tid] else None))
        if name.endswith('/Start'):
            op_stacks[(tid,name[:-6])].append((t,p))
        elif name.endswith('/Stop'):
            key=(tid,name[:-5]); stack=op_stacks[key]
            if stack:
                a,sp=stack.pop()
                if 'ElementId' in sp and 'ElementId' in p and sp['ElementId']!=p['ElementId']: malformed['elementPairMismatch']+=1; continue
                span=dict(op=key[1],tid=tid,start=a,end=t,ms=(t-a)*1000/frequency,payload=sp)
                if key[1]=='Frame': frames.append(span)
                if selected(a) or selected(t): spans.append(span)
            else: malformed[name]+=1
            if name=='PlaceElement/Stop' and active_places[tid]: active_places[tid].pop()
ui_tid=tids.most_common(1)[0][0]
results=[]
for n,c in enumerate(commands):
    if c['index'] not in indices: continue
    boundary=commands[n+1]['begin'] if n+1<len(commands) else c['begin']+2200000
    candidates=[f for f in frames if f['tid']==ui_tid and f['start']<boundary and f['end']>c['begin']]
    if not candidates: results.append(dict(command=c,frame=None)); continue
    frame=max(candidates,key=lambda x:x['ms']); a,b=frame['start'],frame['end']
    inside=[s for s in spans if s['tid']==ui_tid and a<=s['start'] and s['end']<=b]
    entries=[e for e in retained if e['tid']==ui_tid and a<=e['t']<=b]
    ops=collections.defaultdict(list)
    for s in inside: ops[s['op']].append(s)
    totals={op:dict(count=len(ss),inclusiveMs=sum(s['ms'] for s in ss),unionMs=union_ms((s['start'],s['end']) for s in ss)) for op,ss in ops.items()}
    templates=[e for e in entries if e['name']=='ApplyTemplate/Start']
    identities={}
    for e in templates:
        ident=e['p']['ElementId']; life=lifetimes[ident]
        if ident in identities: continue
        identities[ident]=dict(cls=e['p'].get('ClassName'),rows=[r for tt,r in life['rows'] if tt<=b],firstSeen=life['first'],createdBefore=[t for t in life['created'] if t<a],createdInFrame=[t for t in life['created'] if a<=t<=b],destroyedBefore=[t for t in life['destroyed'] if t<a],destroyedInFrame=[t for t in life['destroyed'] if a<=t<=b])
    results.append(dict(command=c,frame=frame,totals=totals,rows=sorted({s['payload']['ItemIndex'] for s in inside if s['op']=='PlaceElement'}),templateCounts=collections.Counter(e['p'].get('ClassName') for e in templates),identities=identities,nativeCreated=sum(e['name']=='ElementCreated' for e in entries),nativeDestroyed=sum(e['name']=='ElementDestroyed' for e in entries),longest=sorted(inside,key=lambda x:-x['ms'])[:30]))
result=dict(source=plan['source'],condition=plan['condition'],processEvents=str(events),uiTid=ui_tid,frameThreads=dict(tids),pairErrors=dict(malformed),unpaired={str(k):len(v) for k,v in op_stacks.items() if v},commands=results,caveats=['Inclusive spans overlap; use unions within a category, never sum nested categories.','Rows come from native PlaceElement nesting, not requested offsets.','Pointer identity is valid within this process only; inspect creation/destruction epochs.','Profiled timings are attribution, not an acceptance series.'])
destination.write_text(json.dumps(result,indent=2))
print(json.dumps(dict(uiTid=ui_tid,pairErrors=dict(malformed),commands=[dict(index=r['command']['index'],frameMs=r['frame']['ms'] if r['frame'] else None,rows=r.get('rows'),created=r.get('nativeCreated'),templates=r.get('templateCounts'),totals=r.get('totals')) for r in results]),indent=2))
