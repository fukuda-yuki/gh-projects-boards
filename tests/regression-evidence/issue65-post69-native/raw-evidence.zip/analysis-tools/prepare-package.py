import hashlib,json,pathlib,shutil,xml.etree.ElementTree as ET
repo=pathlib.Path.cwd();task=repo/'TestResults/issue65-post69-native';dest=repo/'tests/regression-evidence/issue65-post69-native'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
ui=['run-20260922-171437-910-639b2ef2','run-20260922-172806-143-4e70b9f4','run-20260922-173916-151-87e0e0c4']
e2e='20260922-172923-a6c85b5904604b9999aa7d62c874378e'
temporary=pathlib.Path(r'C:/Users/mwam0/AppData/Local/Temp')
host={name:str(temporary/folder) for name,folder in {
 'light':'ghpb-theme-9561a024cde14b2ea23151a1a60b2383',
 'dark':'ghpb-theme-5f3bfa7ec87a4a86ab97899704bc0478',
 'focused-pending':'ghpb-focused-scroll-1dbbd70478744d05a643c6e5e6ae220e',
 'focused-no-pending':'ghpb-focused-scroll-2f63bc50e3bd41a4b2e15018793cd874'}.items()}
(task/'validation-inputs.json').write_text(json.dumps(dict(uiRuns=ui,e2eRun=e2e,extraDiagnostics=['post69-viewport-thumb-01'],hostObservations=host),indent=2))
executions=[]
for name in ui:
 root=repo/'TestResults/ui-integration'/name;result=ET.parse(root/'results.xml').getroot();meta=read(root/'metadata.json')
 executions.append(dict(id=name,boundary='real-control UI integration',mechanism='host and native input',environment='synthetic offline',source=meta['source'],command=meta['command'],counts={k:result.attrib.get(k) for k in ['total','passed','failed','skipped','inconclusive']},result=result.attrib['result'],durationSeconds=result.attrib['duration'],artifacts=f'ui-integration/{name}'))
root=repo/'TestResults/e2e'/e2e;meta=read(root/'metadata.json');counts=ET.parse(root/'e2e.trx').find('.//{*}Counters').attrib
executions.append(dict(id=e2e,boundary='one ordinary Gantt journey plus two native physical IME cases',mechanism='ordinary WinUI executable and public UI Automation/physical keys',environment='isolated synthetic fixture, fake gh',metadata=meta,counts=counts,artifacts='e2e'))
runs=pathlib.Path(r'C:/Users/mwam0/.codex/worktrees/i65-residual/TestResults/issue61-65')
names=['post69-native-candidate-cold-01','post69-native-candidate-warm-01','post69-viewport-before-short-01','post69-viewport-after-short-01']+[f'post69-viewport-final-{c}-{i:02}' for i in range(1,4) for c in ['cold','warm']]+['post69-viewport-thumb-01']
for name in names:
 root=runs/name;env=read(root/'environment.json');counts=ET.parse(root/'diagnostic.trx').find('.//{*}Counters').attrib
 executions.append(dict(id=name,boundary='whole ordinary application through durable state',mechanism='retained producer/driver and physical input, timestamped ROI captures',environment='synthetic fixture; native profiler only for candidate attribution pair',source=env['sourceRevision'],command=env['command'],condition=env['condition'],mode=env['mode'],counts=counts,performance='separate; final scroll gate FAIL',artifacts=('extra-diagnostics/' if name.endswith('thumb-01') else 'runs/')+name))
(dest/'executions.json').write_text(json.dumps(executions,indent=2))
pixels=[
 ('theme-light.png',pathlib.Path(host['light'])/'workspace-light.png','Actual hosted Light pending editor'),
 ('theme-dark.png',pathlib.Path(host['dark'])/'workspace-dark.png','Actual hosted Dark pending editor'),
 ('focused-pending-return.png',pathlib.Path(host['focused-pending'])/'04-return-top-left.png','Same pending title/caret after both-axis return'),
 ('thumb-row1000-edit.png',runs/'post69-viewport-thumb-01/observations/distant-edit.png','Ordinary native scrollbar journey and immediate row 1000 title input'),
 ('final-cold01-unchanged.png',runs/'post69-viewport-final-cold-01/observations/scroll-0002.png','Command 0 unchanged viewport; timing comes from original capture/driver records'),
 ('final-cold01-changed.png',runs/'post69-viewport-final-cold-01/observations/scroll-0003.png','Command 0 first changed capture shows row 241 destination'),
 ('native-candidate-first-destination.png',runs/'post69-native-candidate-cold-01/observations/scroll-0040.png','Profiled first destination visible rows 721 through 732')]
(task/'pixels').mkdir(exist_ok=True);records=[]
for name,source,meaning in pixels:
 shutil.copy2(source,task/'pixels'/name);records.append(dict(path='pixels/'+name,source=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),observation=meaning,review='Viewed original pixels; synthetic content; not human acceptance'))
(task/'pixels.json').write_text(json.dumps(records,indent=2))
receipt=task/'analysis/README.md'
with receipt.open('a') as f:f.write('\n## Execution disposition after explicit consent\n\nThe preparation-only state above is historical. On 2026-09-22 the user explicitly permitted launch and supplied UAC approval. The named CPU/XAMLActivity session completed and finalized with exit 0 and zero lost events. Post-69 native comparison, causal viewport correction b66d8f9, short comparison, six final unprofiled repetitions and scoped guards are complete. Functional checks pass; final scroll gate FAIL. See tests/regression-evidence/issue65-post69-native for the current receipt. Do not relaunch the single-use capture.\n')
print(json.dumps({'executions':len(executions),'pixels':len(records)}))
