import collections, hashlib, json, pathlib, shutil, zipfile, xml.etree.ElementTree as ET

repo=pathlib.Path.cwd(); task=repo/'TestResults/issue65-post69-native'; dest=repo/'tests/regression-evidence/issue65-post69-native'
runs=pathlib.Path(r'C:/Users/mwam0/.codex/worktrees/i65-residual/TestResults/issue61-65')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
config=read(task/'validation-inputs.json'); raw=task/'portable-evidence'
if raw.exists():raise RuntimeError('Preserve the earlier package; choose a fresh staging directory.')
raw.mkdir()
def copy(src,target):
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
names=['post69-native-candidate-cold-01','post69-native-candidate-warm-01','post69-viewport-before-short-01','post69-viewport-after-short-01']+[f'post69-viewport-final-{c}-{i:02}' for i in range(1,4) for c in ['cold','warm']]
summaries=[]
for name in names:
    root=runs/name;obs=root/'observations';target=raw/'runs'/name
    plan=read(obs/'plan.json');m=read(obs/'measurements.json');cl=read(obs/'native-command-classification.json');intervals=read(obs/'native-scroll-intervals.json')
    profile=name.startswith('post69-native-candidate-')
    trx=ET.parse(root/'diagnostic.trx');counts=trx.find('.//{*}Counters').attrib
    assert counts['executed']=='1' and counts['passed']=='1' and counts['failed']=='0', (name,counts)
    summary=dict(run=name,source=plan['source'],condition=plan['condition'],appSha256=plan['appSha256'],executableSha256=plan['executableSha256'],coreSha256=plan['coreSha256'],driverSha256=plan['driverSha256'],profiled=profile,traceComplete=m['traceComplete'],typed=m['typed'],renderingGaps=m['renderingGaps'],captureGaps=m['captureGaps'],scrollIntervals=len(intervals),scrollIntervalMaxMs=max((x['ms'] for x in intervals),default=None),commandCounts=cl['counts'],postSaveCounts=cl['postSaveCounts'],state='PASS',scroll='See explicit final disposition in README; absence of classified failures is not screen-presentation acceptance.')
    summaries.append(summary)
    for file in ['environment.json','diagnostic.trx','test.log','seed.log']:
        if (root/file).exists():copy(root/file,target/file)
    for file in ['plan.json','driver.jsonl','app-trace.jsonl','measurements.json','scroll-captures.json','native-command-classification.json','native-scroll-intervals.json','durable-readback.json','lifetime.json']:
        copy(obs/file,target/'observations'/file)
    # Every capture is synthetic and part of the declared app ROI. Retain enough
    # source pixels to reproduce the classification, not only favorable examples.
    for file in ['ready.png','after-workload.png']+[c['path'] for c in read(obs/'scroll-captures.json')]:
        copy(obs/file,target/'observations'/file)
(dest/'runs.json').write_text(json.dumps(summaries,indent=2))
comparison=read(task/'analysis/comparison.json');(dest/'native-comparison.json').write_text(json.dumps(comparison,indent=2))
baseline=repo/'TestResults/issue65-native-preflight/capture-20260922-150303'
for label,base,frames,samples,scheduling in [('baseline',baseline,task/'analysis/baseline-frames.json',baseline/'ui-samples-xaml.jsonl',baseline/'ui-scheduling.jsonl'),*[(c,task/f'candidate-01/{c}',task/f'candidate-01/{c}/frames.json',task/f'candidate-01/{c}/details/samples.jsonl',task/f'candidate-01/{c}/details/scheduling.jsonl') for c in ['cold','warm']]]:
    target=raw/'native'/label;report=read(frames)
    windows=[(c['frame']['start'],c['frame']['end']) for c in report['commands'] if c['command']['index'] in (12,81,91)]
    copy(frames,target/'frames.json');copy(base/'trace-metadata.json',target/'trace-metadata.json')
    selected_elements={int(k) for c in report['commands'] for k in c.get('identities',{})}
    for source,filename,timekey in [(base/'product-events.jsonl','selected-frame-events.jsonl','TimeStampQPC'),(samples,'selected-frame-samples.jsonl','TimeStampQPC')]:
        with source.open(encoding='utf-8-sig') as inp,(target/filename).open('w') as out,(target/(filename+'.lifetimes.jsonl')).open('w') as life:
            for line in inp:
                e=json.loads(line);t=e[timekey]
                if any(a<=t<=b for a,b in windows):out.write(line)
                if filename=='selected-frame-events.jsonl' and e.get('payload',{}).get('ElementId') in selected_elements and e['EventName'] in ['ElementCreated','ElementDestroyed','ApplyTemplate/Start']:
                    life.write(line)
    # Product-UI-thread scheduling only; the system trace never enters this archive.
    copy(scheduling,target/'ui-thread-scheduling.jsonl')
    modules=[{k:(pathlib.PureWindowsPath(v).name if k in ['FilePath','PdbName'] else v) for k,v in m.items()} for m in read(base/'modules.json') if 'trial-app' in m['FilePath'] or 'final-app' in m['FilePath']]
    (target/'product-xaml-modules.json').write_text(json.dumps(modules,indent=2))
for name in ['native-tree-summary.json','symbol-range-check.json','xaml-codeview-check.json']:
    copy(task/'analysis'/name,raw/'native'/name)
for name in ['plan.json','driver.jsonl','app-trace.jsonl','measurements.json','native-command-classification.json','scroll-captures.json']:
    copy(runs/'native-attribution-cold-01/observations'/name,raw/'native/baseline/observations'/name)
for name in config['uiRuns']:
    for p in (repo/'TestResults/ui-integration'/name).iterdir():
        if p.is_file():copy(p,raw/'ui-integration'/name/p.name)
for p in (repo/'TestResults/e2e'/config['e2eRun']).iterdir():
    if p.is_file() and not p.name.endswith('assets.json'):copy(p,raw/'e2e'/p.name)
for folder in (repo/'TestResults/e2e'/config['e2eRun']).glob('registration-*'):
    for p in folder.iterdir():
        if p.is_file():copy(p,raw/'e2e'/folder.name/p.name)
for name,folder in config.get('hostObservations',{}).items():
    for p in pathlib.Path(folder).iterdir():
        if p.is_file():copy(p,raw/'host-observations'/name/p.name)
for name in config.get('extraDiagnostics',[]):
    root=runs/name
    for file in ['environment.json','diagnostic.trx','test.log']:
        copy(root/file,raw/'extra-diagnostics'/name/file)
    for p in (root/'observations').iterdir():
        if p.is_file() and p.name!='synthetic-final-checkpoint.json':copy(p,raw/'extra-diagnostics'/name/'observations'/p.name)
for p in (task/'analysis').glob('*.py'):copy(p,raw/'analysis-tools'/p.name)
for source,file in [(repo/'TestResults/issue65-native-preflight/classify.py','classify.py'),(repo/'TestResults/issue65-native-preflight/intervals.py','intervals.py'),(repo/'scripts/Measure-SustainedInput.ps1','Measure-SustainedInput.ps1')]:copy(source,raw/'analysis-tools'/file)
for file in ['Program.cs','Parser.csproj']:copy(task/'analysis/decoder'/file,raw/'analysis-tools/decoder'/file)
for file in ['Program.cs','Details.csproj']:copy(task/'analysis/details'/file,raw/'analysis-tools/details'/file)
for file in ['capture.ps1','resume.ps1','launch-attempt.json','ready.txt','start.txt','stop.txt','stop-exit.txt','status-default-before.txt','status-owned-before.txt','status-owned-after.txt','done.txt']:
    copy(task/'candidate-01'/file,raw/'capture-controller'/file)
copy(task/'viewport-binary.json',raw/'viewport-binary.json')
copy(task/'validation-inputs.json',raw/'validation-inputs.json')
for p in (task/'pixels').glob('*.png'):copy(p,dest/'pixels'/p.name)
copy(task/'pixels.json',dest/'pixels.json')
with zipfile.ZipFile(dest/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    capture_index=[];objects=set()
    for p in sorted(raw.rglob('*')):
        if not p.is_file():continue
        relative=p.relative_to(raw).as_posix()
        if p.suffix=='.png':
            digest=hashlib.sha256(p.read_bytes()).hexdigest();object_path=f'capture-objects/{digest}.png'
            if digest not in objects:archive.write(p,object_path);objects.add(digest)
            capture_index.append(dict(path=relative,object=object_path,sha256=digest))
        else:archive.write(p,relative)
    archive.writestr('capture-index.json',json.dumps(capture_index,indent=2))
manifest=[dict(path=p.relative_to(dest).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(dest.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json']
(dest/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(dict(archiveBytes=(dest/'raw-evidence.zip').stat().st_size,files=sum(p.is_file() for p in raw.rglob('*')))))
