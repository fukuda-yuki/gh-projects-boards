"""Collect existing synthetic evidence; never execute or overwrite a test run."""
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
out = repo / 'tests/regression-evidence/issue65-residual'
out.mkdir(exist_ok=True)
archive = out / 'raw-evidence.zip'
ledger, entries = [], []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    def add(p):
        if not p.is_file(): return
        name = p.relative_to(repo).as_posix()
        z.write(p, name)
        entries.append(dict(path=name, bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    for run in sorted((repo / 'TestResults/ui-integration').glob('run-*')):
        meta_file = run / 'metadata.json'
        if not meta_file.exists(): continue
        meta = json.loads(meta_file.read_text(encoding='utf-8-sig'))
        ledger.append(dict(kind='hosted-ui', run=run.name, metadata=meta))
        for p in run.iterdir():
            if p.suffix in ('.json','.xml','.log','.diff'): add(p)
    for run in sorted((repo / 'TestResults/issue61-65').glob('residual-*')):
        env = json.loads((run/'environment.json').read_text(encoding='utf-8-sig'))
        trx = ET.parse(run/'diagnostic.trx').getroot()
        counts = next(e.attrib for e in trx.iter() if e.tag.endswith('Counters'))
        ledger.append(dict(kind='sustained-native',run=run.name,source=env['sourceRevision'],condition=env['condition'],mode=env['mode'],counts=counts,environment=env))
        for p in run.iterdir():
            if p.suffix in ('.json','.log','.trx') and p.name!='synthetic-initial-checkpoint.json': add(p)
        for p in (run/'observations').iterdir():
            if p.suffix in ('.json','.jsonl','.log') and p.name!='synthetic-final-checkpoint.json': add(p)
    for run in sorted((repo / 'TestResults/e2e').glob('*')):
        if not run.is_dir(): continue
        for p in run.iterdir():
            if p.suffix in ('.json','.log','.trx','.txt','.patch'): add(p)
        if (run/'e2e.trx').exists():
            trx=ET.parse(run/'e2e.trx').getroot()
            ledger.append(dict(kind='ordinary-app',run=run.name,counts=next(e.attrib for e in trx.iter() if e.tag.endswith('Counters'))))
    for p in (repo/'TestResults/residual').iterdir():
        if p.is_file() and p.suffix in ('.json','.jsonl','.log','.py','.ps1','.md'): add(p)
    for p in (repo/'TestResults/residual/core').glob('*.trx'): add(p)
    for p in (out/'pixels').glob('*.png'): add(p)
    add(out/'pixel-evidence.json')
(out/'executions.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'artifact-manifest.json').write_text(json.dumps(dict(archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),files=entries,
    omissions='Original complete frame sequences, checkpoints, executable directories and test temporary roots remain in the local run locations; hashes and selected unchanged PNGs are included. This is not a complete binary/fixture distribution.'),indent=2),encoding='utf-8')
for name in ('frozen-candidate.json','scroll-comparison.json','gantt-comparison.json','thread-correlation.json','supplemental.json'):
    shutil.copy2(repo/'TestResults/residual'/name,out/name)
print(json.dumps(dict(archiveBytes=archive.stat().st_size,files=len(entries),runs=len(ledger))))
