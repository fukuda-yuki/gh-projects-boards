"""Summarize existing observations only; no product execution or artifact repair."""
import collections
import hashlib
import json
import shutil
import statistics
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
root = repo / 'TestResults/residual'
out = repo / 'tests/regression-evidence/issue65-residual'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

gantt = {}
for label, run in [('baseline', 'run-20260921-134744-853-3d50befc'), ('final', 'run-20260921-140319-157-4359ab3c')]:
    trace = [json.loads(s) for s in (root / (label+'-gantt.jsonl')).read_text(encoding='utf-8-sig').splitlines()]
    frequency = trace[0]['data']['frequency']
    spans = [e['data'] for e in trace if e['kind'] == 'ui-span']
    saves = [s for s in spans if s['kind'] == 'planning-save-handler']
    stats = {}
    for kind in ['planning-save-handler', 'planning-candidate', 'planning-commit', 'planning-view-refresh', 'rebuild', 'gantt-projection', 'gantt-present']:
        samples = [s for s in spans if s['kind'] == kind and any(a['start'] <= s['start'] and s['end'] <= a['end'] for a in saves)]
        ms = [(s['end']-s['start'])*1000/frequency for s in samples]
        stats[kind] = dict(count=len(ms), meanMs=statistics.mean(ms) if ms else None, maxMs=max(ms, default=None))
    core = collections.defaultdict(list)
    for e in trace:
        if e['kind'] == 'planning-core':
            for s in e['data']['samples']:
                core[s['Kind']].append((s['End']-s['Start'])*1000/frequency)
    public = next(json.loads(line.split(': ',1)[1]) for line in (repo/'TestResults/ui-integration'/run/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('Gantt 1000 replan measurement: '))
    gantt[label] = dict(run=run, public=public, handlerSpansIncludingTwoWarmups=stats,
        allPresentationSpans=sum(s['kind']=='gantt-present' for s in spans),
        core={k:dict(count=len(v),meanMs=statistics.mean(v),maxMs=max(v)) for k,v in core.items()},
        caveat='Nested spans overlap; do not add them. Hosted traces contain complete save-handler spans but no full-process trace-end. The legacy public boundary text mentions UI rebuild; final task-value saves no longer rebuild Boards.')
(root/'gantt-comparison.json').write_text(json.dumps(gantt,indent=2),encoding='utf-8')

pixels = out/'pixels'
pixels.mkdir(exist_ok=True)
obs = repo/'TestResults/issue61-65/residual-final-cold-02/observations'
command = read(obs/'classified-scroll.json')['commands'][91]
capture_rows = read(obs/'scroll-captures.json')
frequency = read(obs/'plan.json')['frequency']
manifest = dict(run='residual-final-cold-02', command=command, captures=[], staticReview=[])
for name in ['scroll-0277.png','scroll-0280.png','scroll-0281.png']:
    source=obs/name
    destination=pixels/('cold02-'+name)
    shutil.copy2(source,destination)
    c=next(c for c in capture_rows if c['path']==name)
    manifest['captures'].append(dict(source=str(source), path=destination.relative_to(out).as_posix(), sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        captureBeginAfterCommandMs=(c['begin']-command['begin'])*1000/frequency,captureEndAfterCommandMs=(c['end']-command['begin'])*1000/frequency))
for name in ['03-bottom-right.png','04-return-top-left.png']:
    source=Path('C:/Users/mwam0/AppData/Local/Temp/ghpb-focused-scroll-4cf605f5188540a8bf49365fce723c11')/name
    destination=pixels/('focused-'+name)
    shutil.copy2(source,destination)
    manifest['staticReview'].append(dict(source=str(source), path=destination.relative_to(out).as_posix(),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        run='run-20260921-135527-300-49d2d613',boundary='Scoped hosted-control RenderTargetBitmap snapshot; not ordinary-app pixel timing or human acceptance.'))
(out/'pixel-evidence.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')

supplement={}
for name in ['residual-final-ime','residual-final-thumb']:
    obs=repo/'TestResults/issue61-65'/name/'observations'
    m=read(obs/'measurements.json')
    driver=[json.loads(s) for s in (obs/'driver.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    supplement[name]=dict(traceComplete=m['traceComplete'],renderingGaps=m['renderingGaps'],captureGaps=m['captureGaps'],
        driverEvents=dict(collections.Counter(e['kind'] for e in driver)),selectedEvents=[e for e in driver if e['kind'] in ['distant-edit','scroll-roundtrip-end','workload-end']])
(root/'supplemental.json').write_text(json.dumps(supplement,indent=2),encoding='utf-8')
print(json.dumps(gantt,indent=2))
print(json.dumps(supplement,indent=2))
print(json.dumps(manifest['captures'],indent=2))
