import collections
import json
import statistics
import sys
from pathlib import Path

repo = Path(__file__).resolve().parents[2]
runs = repo / "TestResults/issue61-65"
results = []
for name in sys.argv[1:]:
    root = runs / name / "observations"
    read = lambda filename: json.loads((root / filename).read_text(encoding="utf-8-sig"))
    m, scroll, plan = read("measurements.json"), read("classified-scroll.json"), read("plan.json")
    trace = [json.loads(line) for line in (root / "app-trace.jsonl").read_text(encoding="utf-8-sig").splitlines()]
    commands = scroll["commands"]
    first, last = commands[0]["begin"], commands[-1]["end"]
    commits = [s["Start"] for e in trace if e["kind"] == "core-checkpoint-trace" for s in e["data"]["samples"]
               if s["Kind"] == "checkpoint-commits" and s["Start"] <= last]
    settled = max(commits, default=first)
    spans = [e["data"] for e in trace if e["kind"] == "ui-span" and first <= e["data"]["start"] <= last]
    visited = {"vertical": {0.0}, "horizontal": {0.0}}
    cohorts = collections.defaultdict(collections.Counter)
    for c in commands:
        axis, offset = c.get("axis"), c.get("requestedOffset")
        if axis is None or offset is None:
            continue
        bucket = axis + ("-return" if round(offset, 2) in visited[axis] else "-new")
        visited[axis].add(round(offset, 2))
        if c["begin"] < settled:
            continue
        cohorts[bucket][c["classification"]] += 1
    work = {}
    for kind in ["realize-row", "release-row", "header-sync", "update"]:
        samples = [s for s in spans if s["kind"] == kind and s["start"] >= settled]
        values = [(s["end"] - s["start"]) * 1000 / plan["frequency"] for s in samples]
        work[kind] = dict(count=len(values), totalMs=sum(values), medianMs=statistics.median(values) if values else None,
                          maxMs=max(values, default=None), allocatedBytes=sum(s.get("managedAllocatedBytesOnThread", 0) or 0 for s in samples))
    cpu = []
    for e in trace:
        d = e.get("data", {})
        if e["kind"] == "rendering-callback" and first <= e["ticks"] <= last and d.get("previousThreadCpu100ns") is not None:
            wall = d["previousGapTicks"] * 1000 / plan["frequency"]
            if wall >= 100:
                cpu.append(dict(end=e["ticks"], wallMs=wall, uiThreadCpuMs=d["previousThreadCpu100ns"] / 10000,
                                unaccountedWallMs=wall-d["previousThreadCpu100ns"] / 10000))
    result = dict(run=name, source=plan["source"], condition=plan["condition"], title=next(v["latency"] for v in m["typed"] if v["phase"]=="title"),
        number=next(v["latency"] for v in m["typed"] if v["phase"]=="number"), traceComplete=m["traceComplete"],
        lastCommitAfterScrollStartMs=(settled-first)*1000/plan["frequency"], commands=scroll["commandCounts"],
        callbackGaps=scroll["callbackCounts"], maximumCallbackGapMs=max((g["milliseconds"] for g in scroll["callbackGaps"]), default=None),
        postSaveCallbackGaps=sum(g["start"]>=settled for g in scroll["callbackGaps"]), postSaveAxes=cohorts, postSaveWork=work,
        optionalThreadCpu=cpu, captureGaps=m["captureGaps"], caveat="Cohorts and callback gaps overlap; never add them as independent failures. Native readback includes UIA. CPU has OS accounting granularity; wall remainder is not a diagnosed wait cause. Not physical scanout.")
    results.append(result)
out = repo / "TestResults/residual/scroll-comparison.json"
out.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
for r in results:
    print(json.dumps({k:r[k] for k in ["run","title","number","commands","maximumCallbackGapMs","postSaveCallbackGaps"]}))
