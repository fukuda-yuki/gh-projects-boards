$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
public static class CoreIlComparison {
    public static Dictionary<string,string> Read(string path) {
        using var file = File.OpenRead(path);
        using var pe = new PEReader(file);
        var reader = pe.GetMetadataReader();
        var result = new Dictionary<string,string>();
        foreach (var handle in reader.MethodDefinitions) {
            var method = reader.GetMethodDefinition(handle);
            if (method.RelativeVirtualAddress == 0) continue;
            var type = reader.GetTypeDefinition(method.GetDeclaringType());
            var key = System.Reflection.Metadata.Ecma335.MetadataTokens.GetToken(handle) + ":" + reader.GetString(type.Namespace) + "." + reader.GetString(type.Name) + ":" + reader.GetString(method.Name) + ":" + Convert.ToHexString(reader.GetBlobBytes(method.Signature));
            var body = pe.GetMethodBody(method.RelativeVirtualAddress);
            result.Add(key, Convert.ToHexString(SHA256.HashData(body.GetILBytes())));
        }
        return result;
    }
}
'@
$before = [CoreIlComparison]::Read((Resolve-Path 'TestResults/issue65-post69-native/viewport-app/GhProjectsBoards.Core.dll'))
$after = [CoreIlComparison]::Read((Resolve-Path 'TestResults/issue65-reset/inactive-app/GhProjectsBoards.Core.dll'))
$keys = @($before.Keys + $after.Keys | Sort-Object -Unique)
$differences = @($keys | Where-Object { -not $before.ContainsKey($_) -or -not $after.ContainsKey($_) -or $before[$_] -ne $after[$_] })
@{ beforeMethods=$before.Count; afterMethods=$after.Count; differentBodies=$differences; boundary='Method signature/name and IL byte comparison only; not binary identity or equality of all metadata.' } | ConvertTo-Json -Depth 5 | Set-Content TestResults/issue65-reset/core-il-comparison.json
Get-Content TestResults/issue65-reset/core-il-comparison.json
